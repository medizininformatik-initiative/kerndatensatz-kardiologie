# Beschreibung des Moduls - MII IG Modul Kardio DE v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* **Beschreibung des Moduls**

## Beschreibung des Moduls

### Einleitung

Das Modul Kardiologie dient der Datenerfassung in strukturierter und standardisierter Form, sodass fachspezifische Informationen zu kardiovaskulären Erkrankungen erfasst werden können. Der verwendete Datensatz umfasst eine Reihe von qualitativen und quantitativen Parametern, die eine Datengrundlage liefern für Diagnostik und Behandlung kardiovaskulärer Erkrankungen. Zudem sind sogenannte prädiktive Score-Parameter eingeschlossen, die aufgrund dieser Daten Wahrscheinlichkeiten für kardiovaskuläre Events repräsentieren und den Einfluss von Medikation und Lebensführung einbeziehen.

Die Auswahl der Parameter als Grundlage zur Erfassung von Daten zur Behandlung kardiologischer Patientinnen/en entstand durch Zusammenarbeit von Kardiologinnen/en verschiedener Universitätsklinika in Deutschland und wurde im Rahmen des Medizininformatik-Projekts ACRIBiS erstellt. Als Ausgangspunkte dienten die Datensätze der [DGK](https://dgk.org/) und der [INA](https://www.ina.gematik.de/community-hub/vernetzen-mitwirken/arbeitskreise/erstellung-eines-kardiologischen-basisdatensatzes). Diese wurden nicht in vollem Umfang und Detailgrad übernommen, sondern zugunsten der Handhabbarkeit in reduzierter Form in das KDS-Modul aufgenommen.

Das Basismodul Kardiologie umfasst die Beschreibung der standardisierten und strukturierten medizinischen Datenerfassung kardiovaskulärer Erkrankungen bzw. deren Symptome, Behandlungen oder auch der Medikation. Der Fokus liegt hierbei auf qualitativen und leicht objektivierbaren Parametern in der Anamnese, die als grundlegende Informationen der Arzt-Patienten-Interaktion dienen und dazu dienen diagnostische und therapeutische Entscheidungen zu treffen.

Das langfristige übergeordnete Ziel des kardiologischen Kerndatensatzes ist es, eine, aus klinischer Perspektive zielgerichtete und detaillierte Charakterisierung von Patientinnen/en mit kardiologischen Erkrankungen in standardisierter Form abzubilden, die so eine Nutzung als homogene Forschungsdaten aus verschiedenen Kliniken oder auch Hausarztpraxen ermöglicht.

Das Kerndatensatzmodul Kardiologie wurde als eigenständiges Modul des Kerndatensatzes der MII konzipiert, ist jedoch über die gemeinsame Nutzung von verschiedenen Datenitems mit bereits existierenden Modulen eingebunden. Die untenstehende Graphik zeigt die gegenwärtigen (Stand 08.2026) Module an und in dieser werden die grundlegenden Datenquellen wie Person, Fall oder auch Medikation hervorgehoben. Die Übersicht visualisiert jedoch keine Abhängigkeiten oder inhaltlichen Gemeinsamkeiten der einzelnen Module.

![](Kerndatensatz.png)

(aus: [Medizininformatik Initiative Webseite](https://www.medizininformatik-initiative.de/de/der-kerndatensatz-der-medizininformatik-initiative))

### Zielsetzung

Die im Modul Kardiologie festgelegten Parameter bestimmen die Dateninhalte, die als Patienten - und Versorgungsdaten in der Klinik als auch im Forschungskontext Verwendung finden und langfristig von den Datenintegrationszentren (DIZ) in standardisierter Form bereitgestellt werden können. Die Gesamtheit des kardiologischen Datensatzes enthält neben hoch-spezialisierten Parametern, die gezielt kardiologische Informationen abbilden, auch solche, die notwendigerweise die Person identifizieren und auch grundlegende andere Informationen. Diese sind im Modul Kardiologie abgebildet jedoch werden die Profile und Codierungen aus bereits bestehenden Modulen übernommen, und somit in das System der KDS Module ([Modul Person](https://simplifier.net/packages/de.medizininformatikinitiative.kerndatensatz.person/2025.0.1/~introduction), [Modul ICU](https://simplifier.net/medizininformatikinitiative-modul-intensivmedizin), u.a.) eingebettet und verlinkt. Damit werden die Daten über die Fachgebiete hinweg standardisiert und integriert, zudem werden gesetzliche Standards wie ISiK berücksichtigt, so dass langfristig eine übergreifende Datenerhebung ermöglicht wird.

In der Umsetzung werden drei Stufen durchlaufen, in denen sukzessiv der kardiologische Datensatz erweitert wird und in der Endphase die Parameter des allgemeinen kardiologischen Datensatzes als FHIR Profile vorliegen und zur Nutzung in den DIZen bereitstehen. Die Phasen lassen sich wie folgt definieren:

* **Stufe 1 (aktuell):** Prototypische Umsetzung eines reduzierten Datensatzes der [ACRIBiS-Studie](https://www.medizininformatik-initiative.de/de/acribis-personalisierte-risikobewertungen-fuer-herz-kreislauf-erkrankungen) in deren Fokus sogenannte Kern-Datenitems zur Standardisierung der kardialen Datenerfassung enthalten sind, dies umfasst neben grundlegenden kardiologischen Parametern auch daraus berechnete Score-Werte zur individuellen Risikobewertung.
* **Stufe 2:** Integration weiterer Vorarbeiten aus MII - Forschungsprojekten, Gematik und Patientenvertretungen (vollständiger Datensatz aus [ACRIBiS](https://www.medizininformatik-initiative.de/de/acribis-personalisierte-risikobewertungen-fuer-herz-kreislauf-erkrankungen), [HIGHmed Use Case](https://www.highmed.org/en/highmed-use-case-cardiology), [CAEHR](https://www.medizininformatik-initiative.de/de/digitaler-fortschrittshub-caehr), [INA](https://www.ina.gematik.de/community-hub/vernetzen-mitwirken/arbeitskreise/erstellung-eines-kardiologischen-basisdatensatzes), standardisierte Patientenfragebögen [PROMs](https://future.hospital/wissensdatenbank/details/patientenzentrierte-erfassung-des-wohlbefindens-proms-und-prems), u.a.)
* **Stufe 3:** Erweiterung des Moduls Kardiologie durch die Abbildung zusätzlicher Parameter der kardiologischen Versorgung, die auch seltene Erkrankungen und weitere Risikobewertungen einschliessen.

Das Modul Kardiologie soll in den Datenintegrationszentren (DIZ) bei der Aufbereitung und Bereitstellung von vorhandenen Patientendaten aus dem Versorgungskontext unterstützen. Es baut bewusst auf bereits vorhandenen Modulen des MII-KDS auf (base, meta, icu, isik, Diagnose, Prozedur) und verwendet, wo möglich, bestehende Strukturen wieder.

-------

### Spezifikation der Parameter

Das Modul adressiert:

* **Anamnese und klinische Parameter:** Erfassung der individuellen Krankengeschichte bezüglich von Vorerkrankungen die relevant für die Diagnose und Behandlung von kardiovaskulären Erkrankungen sind (Allergie, Symptom, Klappenvitium, Krankenhausaufenthalte, Echoparameter, etc.)
* **Diagnostik:** Kardiologische Befunde, die aus anamnestischen Daten abgeleitet, festgestellt wurden. (Myokardinfarkt, Embolien, Atherosklerotische Ereignisse, etc.)
* **Skalen:** Strukturierte Bewertung und Einschätzung funktionaler Kapazitäten durch berechnete oder berichtete Zustände (NYHA-Score, modifizierte Rankin-Skala, CCS-Grad, Fontaine-Stadium, etc.)
* **Risikofaktoren:** Parameter, die als besondere Risikofaktoren im Vorfeld oder bei der Entwicklung kardialer Erkrankungen gelten, werden erhoben und unterteilen sich in verhaltensbedingte und genetische Faktoren (Rauchverhalten, familiäre Prädisposition, Alkoholkonsum, etc.)
* **Kardiologische Geräte:** Implantierbare Geräte zur Therapie und Überwachung kardialer Erkrankungen (Schrittmacher, ICD, LVAD/BiVAD, etc.)
* **Prozeduren:** Behandlungen und Eingriffe zu therapeutischem und/oder diagnostischen Zwecken (Device-Implantationen, PCI, Transplantation, etc.)
* **EKG-Metadaten:** Beschreibende Parameter, die EKG-Messungen spezifizieren, sowie aus den Messungen abgeleitete analytische Daten der EKG-Messkurve (Messung, Kanäle, Rasterung, Rohdatenreferenz)

⚠️ Hinweis: Im Kontext der Anamnese wird das anamnestische Nicht-Vorliegen von Erkrankungen ebenfalls abgebildet. Diese Informationen dienen damit ebenso zur Bewertung des Gesundheitszustandes wie Diagnosen manifester Erkrankungen.

