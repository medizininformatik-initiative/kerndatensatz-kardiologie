# Resource MII IG Modul Kardio DE



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "mii-kerndatensatzmodul-kardiologie",
  "language" : "de",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/ImplementationGuide/mii-kerndatensatzmodul-kardiologie",
  "version" : "2027.0.0-ballot.rc1",
  "name" : "MII_IG_MODUL_KARDIO_DE",
  "title" : "MII IG Modul Kardio DE",
  "status" : "draft",
  "date" : "2026-09-03T15:07:11+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "Medizininformatik Initiative - Erweiterungsmodul Kardiologie",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "276"
    }]
  }],
  "packageId" : "mii-kerndatensatzmodul-kardiologie",
  "license" : "CC-BY-4.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "de_basisprofil_r4",
    "uri" : "http://fhir.org/packages/de.basisprofil.r4/ImplementationGuide/de.basisprofil.r4",
    "packageId" : "de.basisprofil.r4",
    "version" : "1.6.0"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_base",
    "uri" : "https://www.medizininformatik-initiative.de/fhir/modul-base/ImplementationGuide/mii-ig-base",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.base",
    "version" : "2027.0.0-ballot.rc1"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_meta",
    "uri" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/ImplementationGuide/mii-ig-meta",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.meta",
    "version" : "2027.0.0-ballot.rc3"
  },
  {
    "id" : "de_gematik_isik",
    "uri" : "http://fhir.org/packages/de.gematik.isik/ImplementationGuide/de.gematik.isik",
    "packageId" : "de.gematik.isik",
    "version" : "6.0.0"
  },
  {
    "id" : "hl7_terminology_r4",
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.1.0"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-all"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludettl"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-expansion-params"
      },
      {
        "url" : "value",
        "valueString" : "../../input/resources/Parameters-mii-param-kardio-manifest.json"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "resource-language-policy"
      },
      {
        "url" : "value",
        "valueString" : "all-ig"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "de"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "wantGen-ttl"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "wantGen-ttl-html"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/expansion-parameters",
      "valueReference" : {
        "reference" : "Parameters/expansion-parameters"
      }
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-all"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludettl"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-expansion-params"
      },
      {
        "url" : "value",
        "valueString" : "../../input/resources/Parameters-mii-param-kardio-manifest.json"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "resource-language-policy"
      },
      {
        "url" : "value",
        "valueString" : "all-ig"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "de"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "wantGen-ttl"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "wantGen-ttl-html"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-mii-cs-kardio-acribis-questionnaire-answer.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-kardio-acribis-questionnaire-answer"
      },
      "name" : "MII CS Kardio ACRIBiS Questionnaire Answer",
      "description" : "Questionnaire-lokale Antwortcodes für den ACRIBiS Follow-Up-Fragebogen.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-mii-cs-kardio-atherosklerotisches-ereignis.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-kardio-atherosklerotisches-ereignis"
      },
      "name" : "MII CS Kardio Atherosklerotisches Ereignis",
      "description" : "Code für ein unbestimmtes atherosklerotisches Ereignis",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-mii-cs-kardio-lebensmittelpunkt.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-kardio-lebensmittelpunkt"
      },
      "name" : "MII CS Kardio Lebensmittelpunkt",
      "description" : "Lebensmittelpunkt des Patienten",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-mii-cs-kardio-modifizierte-rankin-skala.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-kardio-modifizierte-rankin-skala"
      },
      "name" : "MII CS Kardio Modifizierte Rankin Skala",
      "description" : "Beeinträchtigung des Patienten nach Schlaganfall",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-mii-cs-kardio-supplement-snomedct.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-kardio-supplement-snomedct"
      },
      "name" : "MII CS Kardio Supplement [SNOMED CT]",
      "description" : "Supplement mit post-koordinierenden SNOMED CT-Codes aus dem Modul Kardiologie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-anzahl-kh-aufenthalte-wg-hf.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-anzahl-kh-aufenthalte-wg-hf"
      },
      "name" : "MII EXA Kardio Anzahl KH Aufenthalte WG HF",
      "description" : "Beispiel einer Observation für 3 Krankenhausaufenthalte wegen Herzinsuffizienz im letzten Jahr",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-anzahl-kh-aufenthalte-wg-hf|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-anzahl-kh-aufenthalte-wg-hf2.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-anzahl-kh-aufenthalte-wg-hf2"
      },
      "name" : "MII EXA Kardio Anzahl KH Aufenthalte WG HF (mit Angabe 'Weiß nicht')",
      "description" : "Beispiel einer Observation bei Angabe 'Ich weiß es nicht' zu Krankenhausaufenthalte wegen Herzinsuffizienz im letzten Jahr",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-anzahl-kh-aufenthalte-wg-hf|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-atherosklerotisches-erstereignis.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-atherosklerotisches-erstereignis"
      },
      "name" : "MII EXA Kardio Atherosklerotisches Erstereignis",
      "description" : "Beispiel einer Observation für das Datum eines unbestimmten atherosklerotischen Erstereignisses",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-atherosklerotisches-erstereignis|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-kardio-device-icd.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-kardio-device-icd"
      },
      "name" : "MII EXA Kardio Device ICD",
      "description" : "Beispiel eines implantierten Kardioverter-Defibrillators (ICD)",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-device|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-kardio-ekg-durchfuehrung.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-kardio-ekg-durchfuehrung"
      },
      "name" : "MII EXA Kardio EKG Durchführung",
      "description" : "Beispiel einer Durchführung eines 12-Kanal Ruhe-EKGs",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-ekg-durchfuehrung|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-kardio-ekg-geraet-mortara.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-kardio-ekg-geraet-mortara"
      },
      "name" : "MII EXA Kardio EKG Geraet Mortara",
      "description" : "Beispiel eines EKG Gerätes der Firma Mortara Instruments",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-ekg-geraet|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DeviceDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DeviceDefinition-mii-exa-kardio-ekg-geraetedefinition-mortara.html"
      }],
      "reference" : {
        "reference" : "DeviceDefinition/mii-exa-kardio-ekg-geraetedefinition-mortara"
      },
      "name" : "MII EXA Kardio EKG Geraetedefinition Mortara",
      "description" : "Beispiel einer EKG Gerätedefinition für ein EKG-Gerät der Firma Mortara Instruments",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-ekg-geraetedefinition|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-kardio-ekg-kanal-i.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-kardio-ekg-kanal-i"
      },
      "name" : "MII EXA Kardio EKG Kanal I",
      "description" : "Beispiel eines EKG-Kanals (I) eines Gerätes der Firma Mortara Instruments",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-ekg-kanal|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-kardio-ekg-kanal-ii.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-kardio-ekg-kanal-ii"
      },
      "name" : "MII EXA Kardio EKG Kanal II",
      "description" : "Beispiel eines EKG-Kanals (II) eines Gerätes der Firma Mortara Instruments",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-ekg-kanal|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-mii-exa-kardio-ekg-kanal-iii.html"
      }],
      "reference" : {
        "reference" : "Device/mii-exa-kardio-ekg-kanal-iii"
      },
      "name" : "MII EXA Kardio EKG Kanal III",
      "description" : "Beispiel eines EKG-Kanals (III) eines Gerätes der Firma Mortara Instruments",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-ekg-kanal|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-mii-exa-kardio-ekg-referenz.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/mii-exa-kardio-ekg-referenz"
      },
      "name" : "MII EXA Kardio EKG Referenz",
      "description" : "Beispiel einer Referenz auf ein EKG, dessen Rohdaten an einem anderen Ort gespeichert werden.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-ekg-referenz|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-ekg-rr-interval.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-ekg-rr-interval"
      },
      "name" : "MII EXA Kardio EKG RR Interval",
      "description" : "Beispiel einer Observation zur Darstellung des RR Intervals eines aufgezeichneten EKGs",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-ekg-annotation|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-kardio-embolischer-gefaessverschluss.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-kardio-embolischer-gefaessverschluss"
      },
      "name" : "MII EXA Kardio Emoblischer Gefäßverschluss",
      "description" : "Beispiel: Der Patient hat angegeben, einen embolischen Gefäßverschluss gehabt zu haben.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-diagnose|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-geraeteprogrammierung-vvi.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-geraeteprogrammierung-vvi"
      },
      "name" : "MII EXA Kardio Geräteprogrammierung VVI",
      "description" : "Beispiel der Einstellung eines Kardioverter-Defibrillators (ICD) im VVI-Modus",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-geraeteprogrammierung|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-herzinsuffizienz-unbekannt.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-herzinsuffizienz-unbekannt"
      },
      "name" : "MII EXA Kardio Herzinsuffizienz Unbekannt",
      "description" : "Beispiel: Der Patient weiß nicht, ob er Herzinsuffizienz hat.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-diagnose-prozedur-nein-unbekannt|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-kardio-hoehergradiges-vitium.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-kardio-hoehergradiges-vitium"
      },
      "name" : "MII EXA Kardio Höhergradiges Vitium",
      "description" : "Beispiel zur Abbildung eines unbestimmten höhergradigen Klappenvitiums.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-klappenvitium|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-hoehergradiges-vitium-nein.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-hoehergradiges-vitium-nein"
      },
      "name" : "MII EXA Kardio Höhergradiges Vitium Nein",
      "description" : "Beispiel um abzubilden, dass kein höhergradiges Klappenvitium vorliegt.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-diagnose-prozedur-nein-unbekannt|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-kardio-kardiale-deviceimplantation-icd.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-kardio-kardiale-deviceimplantation-icd"
      },
      "name" : "MII EXA Kardio Kardiale Deviceimplantation ICD",
      "description" : "Beispiel einer Implantation eines Kardioverter-Defibrillators (ICD)",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-kardiale-deviceimplantation|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-kein-device.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-kein-device"
      },
      "name" : "MII EXA Kardio Kein Device",
      "description" : "Beispiel: Der Patient hat kein implantiertes kardiales Device.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-diagnose-prozedur-nein-unbekannt|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-lvef.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-lvef"
      },
      "name" : "MII EXA Kardio LVEF",
      "description" : "Beispielhafte Observation einer linksventrikulären Ejektionsfraktion mittels Echokardiographie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-linksventrikulaere-ejektionsfraktion|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-mrs.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-mrs"
      },
      "name" : "MII EXA Kardio MRS",
      "description" : "Beispielhafte Instanz zur Dokumentation der mRS-Skala nach einem Schlaganfall gemäß MII PR Kardio Score mRS.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-score-modifizierte-rankin-skala|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DeviceMetric"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DeviceMetric-mii-exa-kardio-nbg-schrittmachermodus.html"
      }],
      "reference" : {
        "reference" : "DeviceMetric/mii-exa-kardio-nbg-schrittmachermodus"
      },
      "name" : "MII EXA Kardio NBG Schrittmachermodus",
      "description" : "Beispiel einer DeviceMetric für die Geräteprogrammierung eines ICD",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-nbg-schrittmachermodus|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-pci-nein.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-pci-nein"
      },
      "name" : "MII EXA Kardio PCI/Stent Nein",
      "description" : "Beispiel: Der Patient hatte noch keine Koronarintervention mit PCI/Stent.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-diagnose-prozedur-nein-unbekannt|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-mii-exa-kardio-questionnaireresponse-andere.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/mii-exa-kardio-questionnaireresponse-andere"
      },
      "name" : "MII EXA Kardio QuestionnaireResponse Andere",
      "description" : "Beispiel eines ausgefüllten Follow-Up Fragebogens aus Sicht einer Anderen-Person (hier: Study Nurse)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-mii-exa-kardio-questionnaireresponse-angehoerige.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/mii-exa-kardio-questionnaireresponse-angehoerige"
      },
      "name" : "MII EXA Kardio QuestionnaireResponse Angehoerige",
      "description" : "Beispiel eines ausgefüllten Follow-Up Fragebogens aus Sicht eines Angehörigen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-mii-exa-kardio-questionnaireresponse-arzt.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/mii-exa-kardio-questionnaireresponse-arzt"
      },
      "name" : "MII EXA Kardio QuestionnaireResponse Arzt",
      "description" : "Beispiel eines ausgefüllten Follow-Up Fragebogens aus Sicht eines Arztes/Ärztin",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-mii-exa-kardio-questionnaireresponse-patient.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/mii-exa-kardio-questionnaireresponse-patient"
      },
      "name" : "MII EXA Kardio QuestionnaireResponse Patient",
      "description" : "Beispiel eines ausgefüllten Follow-Up Fragebogens aus Sicht eines Patienten/in",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-raucherstatus.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-raucherstatus"
      },
      "name" : "MII EXA Kardio Raucherstatus",
      "description" : "Eine Beispielinstanz zur Darstellung des Rauchverhaltens einer Person gemäß dem Profil MII_PR_Kardio_Observation_Rauchen.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-observation-rauchen|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-mii-exa-kardio-rolle-kardiologe.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/mii-exa-kardio-rolle-kardiologe"
      },
      "name" : "MII EXA Kardio Rolle Kardiologe",
      "description" : "Beispielhafte Rolle eines Kardiologen zur Verwendung in performer-Referenzen.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-kardio-score-nyha-ii.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-kardio-score-nyha-ii"
      },
      "name" : "MII EXA Kardio Score NYHA II",
      "description" : "Beispielhafte Instanz zur Dokumentation der NYHA-Klassifikation bei Herzinsuffizienz gemäß MII PR Kardio Score NYHA.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-score-nyha|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-kardio-diagnose-myokardinfarkt.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-kardio-diagnose-myokardinfarkt"
      },
      "name" : "MII Kardio Diagnose Myokardinfarkt",
      "description" : "Beispielhafte vollständige Instanz einer Diagnose die vom Arzt bestätigt tatsächlich vorliegt gemäß dem Profil MII_PR_Kardio_Diagnose im Rahmen des ACRIBIS-Projekts.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/StructureDefinition/mii-pr-kardio-diagnose|2027.0.0-ballot.rc1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Parameters-mii-param-kardio-manifest.html"
      }],
      "reference" : {
        "reference" : "Parameters/mii-param-kardio-manifest"
      },
      "name" : "MII Param Kardio Manifest",
      "description" : "Manifest zur zentralen Festlegung der verwendeten Versionen verschiedener Referenzen.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-anzahl-kh-aufenthalte-wg-hf.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-anzahl-kh-aufenthalte-wg-hf"
      },
      "name" : "MII PR Kardio Anzahl KH Aufenthalte wg HF",
      "description" : "Profil zur Erfassung des Anzahl von Krankenhausaufenthalten wegen Herzinsuffizienz in einem Zeitraum im Kontext von ACRIBiS.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-atherosklerotisches-erstereignis.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-atherosklerotisches-erstereignis"
      },
      "name" : "MII PR Kardio Atherosklerotisches Erstereignis",
      "description" : "Profil zur Erfassung des Datum des ersten  atherosklerotischen Ereignisses im Kontext von ACRIBiS.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-device.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-device"
      },
      "name" : "MII PR Kardio Device",
      "description" : "Profil zur Abbildung eines implantierten Herzschrittmachers, Defibrillators oder ventrikulären Unterstützungssystems.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-diagnose.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-diagnose"
      },
      "name" : "MII PR Kardio Diagnose",
      "description" : "Profil zur Abbildung einer Diagnose im Kontext des Projekts Acribis.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-diagnose-prozedur-nein-unbekannt.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-diagnose-prozedur-nein-unbekannt"
      },
      "name" : "MII PR Kardio Diagnose Prozedur Nein Unbekannt",
      "description" : "Dieses Profil bildet das anamnestische Nichtvorliegen einer Diagnose, bzw. Prozedur, oder Unklarheit darüber ab.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-ekg-annotation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-ekg-annotation"
      },
      "name" : "MII PR Kardio EKG Annotation",
      "description" : "Profil zur Erfassung von Annotationen, z.B. Messergebnisse und Interpretationen, eines EKG.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-ekg-durchfuehrung.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-ekg-durchfuehrung"
      },
      "name" : "MII PR Kardio EKG Durchführung",
      "description" : "Profil zur Erfassung der Durchführung eines EKG.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-ekg-geraet.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-ekg-geraet"
      },
      "name" : "MII PR Kardio EKG Gerät",
      "description" : "Profil zur Abbildung eines EKG-Gerätes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-ekg-geraetedefinition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-ekg-geraetedefinition"
      },
      "name" : "MII PR Kardio EKG Gerätedefinition",
      "description" : "Profil zur Abbildung einer EKG-Gerätedefinition.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-ekg-kanal.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-ekg-kanal"
      },
      "name" : "MII PR Kardio EKG Kanal",
      "description" : "Profil zur Abbildung eines EKG-Kanals.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-ekg-referenz.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-ekg-referenz"
      },
      "name" : "MII PR Kardio EKG Referenz",
      "description" : "Profil zur Referenzierung eines EKGs dessen Rohdaten an einem anderen Ort gespeichert werden.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-geraeteprogrammierung.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-geraeteprogrammierung"
      },
      "name" : "MII PR Kardio Geräteprogrammierung",
      "description" : "Mit dieser Observation kann die Geräteprogrammierung, d.h. die DeviceMetric *Schrittmachermodus*, eines Gerätes zu einem bestimmten Zeitpunkt abgebildet werden.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-kardiale-deviceimplantation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-kardiale-deviceimplantation"
      },
      "name" : "MII PR Kardio Kardiale Deviceimplantation",
      "description" : "Profil zur Erfassung einer Implantation eines Herzschrittmachers, Kardioverter-Defibrillators oder ventrikulären Unterstützungssystems.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-klappenvitium.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-klappenvitium"
      },
      "name" : "MII PR Kardio Klappenvitium",
      "description" : "Profil zur Abbildung einer Herzklappenerkrankung.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-linksventrikulaere-ejektionsfraktion.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-linksventrikulaere-ejektionsfraktion"
      },
      "name" : "MII PR Kardio Linksventrikulaere Ejektionsfraktion",
      "description" : "Profil zur Angabe eines Untersuchungsergebnisses zur LVEF im Kontext des Projekts Acribis.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-nbg-schrittmachermodus.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-nbg-schrittmachermodus"
      },
      "name" : "MII PR Kardio NBG Schrittmachermodus",
      "description" : "Dieses Profil bildet die Einstellungsmöglichkeit eines Herzschrittmacher nach dem NBG-Standard ab.\r\nDie konkrete Programmierung eines Herzschrittmachers zu einem bestimmmten Zeitpunkt oder in einem Zeitraum wird in einer Observation abgebildet.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-observation-rauchen.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-observation-rauchen"
      },
      "name" : "MII PR Kardio Observation Rauchen",
      "description" : "Profil zur Erfassung des Rauchverhaltens einer Person im Kontext des Modul Kardiologie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-score-modifizierte-rankin-skala.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-score-modifizierte-rankin-skala"
      },
      "name" : "MII PR Kardio Score Modifizierte Rankin Skala",
      "description" : "Profil zur Erfassung des Outcomes eines Schlaganfalls mittels modifizierter Rankin-Skala.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-kardio-score-nyha.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-kardio-score-nyha"
      },
      "name" : "MII PR Kardio Score NYHA",
      "description" : "Profil zur Erfassung der Einstufung der Stadien einer Herzinsuffizienz nach der New York Heart Association.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-mii-qn-kardio-acribis-study-followup.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/mii-qn-kardio-acribis-study-followup"
      },
      "name" : "MII QN Kardio Acribis Study FollowUp",
      "description" : "Follow-Up-Fragebogen für die ACRIBiS-Studie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-allergene-snomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-allergene-snomedct"
      },
      "name" : "MII VS Kardio Allergene [SNOMED CT]",
      "description" : "Liste von Substanzen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-atherosklerotisches-ereignis-snomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-atherosklerotisches-ereignis-snomedct"
      },
      "name" : "MII VS Kardio Atherosklerotisches Ereignis [SNOMED CT]",
      "description" : "ValueSet for Relevant Codes for Atherosclerotic Events",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-ekg-kanaele-mdc.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-ekg-kanaele-mdc"
      },
      "name" : "MII VS Kardio EKG Kanäle [MDC]",
      "description" : "ISO/IEEE 11073-10101 Codes für EKG Kanäle",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-ekg-prozedur-snomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-ekg-prozedur-snomedct"
      },
      "name" : "MII VS Kardio EKG Prozedur [SNOMED CT]",
      "description" : "SNOMED CT Codes für verschieden EKG-Prozeduren.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-ethnie-snomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-ethnie-snomedct"
      },
      "name" : "MII VS Kardio Ethnie [SNOMED CT]",
      "description" : "SNOMED CT Codes für die Ethnie (in SNOMED CT derzeit als \"racial group\") im Kerndatensatz Kardiologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-extended-condition-severity-snomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-extended-condition-severity-snomedct"
      },
      "name" : "MII VS Kardio Extended Condition Severity [SNOMED CT]",
      "description" : "An extended ValueSet including standard condition severity and SNOMED CT code 42796001 (End-stage)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-extended-mii-diagnosecodes-snomed.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-extended-mii-diagnosecodes-snomed"
      },
      "name" : "MII VS Kardio Extended MII DiagnoseCodes [SNOMED CT]",
      "description" : "Erweiterung des MII VS Diagnose Diagnosecodes [SNOMED CT]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-geraeteprogrammierung-mdc.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-geraeteprogrammierung-mdc"
      },
      "name" : "MII VS Kardio Geräteprogrammierung [MDC]",
      "description" : "Dieses Value Set bildet die Programmierung eines implantierten Gerätes in der Kardiologie ab.\nDazu werden Codes der ISO/IEEE 11073-10101 Nomenclature verwendet.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-geraetetyp-snomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-geraetetyp-snomedct"
      },
      "name" : "MII VS Kardio Gerätetyp [SNOMED CT]",
      "description" : "Dieses Value Set bildet die Gerätetypen implantierter Kardioverter-Defibrillator, Herzschrittmacher und ventrikuläres Unterstützungssystem ab.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-gewichtsveraenderung-snomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-gewichtsveraenderung-snomedct"
      },
      "name" : "MII VS Kardio Gewichtsveraenderung [SNOMED CT]",
      "description" : "Beschreibung von Gewichtsveränderungen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-kardiale-deviceimplantation-koerperstelle-snomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-kardiale-deviceimplantation-koerperstelle-snomedct"
      },
      "name" : "MII VS Kardio Kardiale Devicemimplantation Körperstelle [SNOMED CT]",
      "description" : "Dieses Value Set bildet die Körperstellen, an denen eine Implantation eines kardialen Devices stattfindet, ab.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-kardiale-deviceimplantation-ops.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-kardiale-deviceimplantation-ops"
      },
      "name" : "MII VS Kardio Kardiale Devicemimplantation [OPS]",
      "description" : "Dieses Value Set bildet die Implantation der kardialen Devices Kardioverter-Defibrillator (ICD), Herzschrittmacher zur kardialen Resynchronationstherapie (CRT) und ventrikuläre Unterstützungssysteme ab (VAD).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-kardiale-deviceimplantation-scnomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-kardiale-deviceimplantation-scnomedct"
      },
      "name" : "MII VS Kardio Kardiale Devicemimplantation [SNOMED CT]",
      "description" : "Dieses Value Set bildet die Implantation der kardialen Devices Kardioverter-Defibrillator (ICD), Herzschrittmacher zur kardialen Resynchronationstherapie (CRT) und ventrikuläre Unterstützungssysteme ab (VAD).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-klappenvitium-grad-snomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-klappenvitium-grad-snomedct"
      },
      "name" : "MII VS Kardio Klappenvitium Grad [SNOMED CT]",
      "description" : "SNOMED CT Codes für den Grad Klappenerkrankungen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-klappenvitium-alphaid.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-klappenvitium-alphaid"
      },
      "name" : "MII VS Kardio Klappenvitium [ALPHA-ID]",
      "description" : "Alpha-ID-Codes für Klappenerkrankungen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-klappenvitium-icd.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-klappenvitium-icd"
      },
      "name" : "MII VS Kardio Klappenvitium [ICD 10 GM]",
      "description" : "ICD-Codes für Klappenerkrankungen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-klappenvitium-snomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-klappenvitium-snomedct"
      },
      "name" : "MII VS Kardio Klappenvitium [SNOMED CT]",
      "description" : "SNOMED CT Codes für Klappenerkrankungen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-lebensmittelpunkt-m49.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-lebensmittelpunkt-m49"
      },
      "name" : "MII VS Kardio Lebensmittelpunkt [M49]",
      "description" : "Dieses Value Set bildet den aktuellen Lebensmittelpunkt des Patienten unabhängig von seiner Herkunft ab. Damit wird der Parameter 'Geographic region' des SMART-REACH-Scores mit der Ergänzung Deutschland abgebildet.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-objekte-geraete-mdc.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-objekte-geraete-mdc"
      },
      "name" : "MII VS Kardio MDC Objects Devices [MDC]",
      "description" : "ISO/IEEE 11073-10101 Codes für Objekte und Geräte (Partition 1)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-metriken-ekg-annotationen-mdc.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-metriken-ekg-annotationen-mdc"
      },
      "name" : "MII VS Kardio Metriken EKG Annotationen [MDC]",
      "description" : "ISO/IEEE 11073 Codes für Metriken (Part 2) und EKG Annotationen (Part 10)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-modifizierte-rankin-skala.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-modifizierte-rankin-skala"
      },
      "name" : "MII VS Kardio Modifizierte Rankin Skala",
      "description" : "Stufen der modifizierten Rankin-Skala",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-nein-unbekannt.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-nein-unbekannt"
      },
      "name" : "MII VS Kardio Nein Unbekannt",
      "description" : "ValueSet mit Codes zum Abbilden des anamnestischen Nichtvorliegens einer Diagnose, bzw. Prozedur, oder Unklarheit darüber.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-kardio-nyha-klassen-snomedct.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-kardio-nyha-klassen-snomedct"
      },
      "name" : "MII VS Kardio NYHA Klassen [SNOMED CT]",
      "description" : "Klassen der New York Heart Association Classification",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "release-notes.html"
        }],
        "nameUrl" : "release-notes.html",
        "title" : "Release Notes",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "module-description.html"
        }],
        "nameUrl" : "module-description.html",
        "title" : "Beschreibung des Moduls",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "context.html"
        }],
        "nameUrl" : "context.html",
        "title" : "Kontext und Bezüge zu anderen Modulen",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "scenarios.html"
        }],
        "nameUrl" : "scenarios.html",
        "title" : "Anwendungsszenarien",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "datasets.html"
        }],
        "nameUrl" : "datasets.html",
        "title" : "Datensätze und Beschreibungen",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "information-model.html"
        }],
        "nameUrl" : "information-model.html",
        "title" : "Informationsmodell (UML)",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "profiles-overview.html"
        }],
        "nameUrl" : "profiles-overview.html",
        "title" : "Profilübersicht",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "profiles-anamnese.html"
        }],
        "nameUrl" : "profiles-anamnese.html",
        "title" : "Profile: Anamnese",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "profiles-diagnostik.html"
        }],
        "nameUrl" : "profiles-diagnostik.html",
        "title" : "Profile: Diagnostik",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "profiles-skalen.html"
        }],
        "nameUrl" : "profiles-skalen.html",
        "title" : "Profile: Skalen",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "profiles-risikofaktoren.html"
        }],
        "nameUrl" : "profiles-risikofaktoren.html",
        "title" : "Profile: Risikofaktoren",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "profiles-kardiodevices.html"
        }],
        "nameUrl" : "profiles-kardiodevices.html",
        "title" : "Profile: KardioDevices",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "profiles-ekg.html"
        }],
        "nameUrl" : "profiles-ekg.html",
        "title" : "Profile: EKG-Metadaten",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "terminology.html"
        }],
        "nameUrl" : "terminology.html",
        "title" : "Terminologien",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "references.html"
        }],
        "nameUrl" : "references.html",
        "title" : "Referenzen",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
