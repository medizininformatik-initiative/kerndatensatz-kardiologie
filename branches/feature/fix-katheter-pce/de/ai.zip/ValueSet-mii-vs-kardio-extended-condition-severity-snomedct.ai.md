# MII VS Kardio Extended Condition Severity [SNOMED CT] - MII IG Modul Kardio DE v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII VS Kardio Extended Condition Severity [SNOMED CT]**

## ValueSet: MII VS Kardio Extended Condition Severity [SNOMED CT] 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/ValueSet/mii-vs-kardio-extended-condition-severity-snomedct | *Version*:2027.0.0-ballot |
| Active Stand: 2026-09-28 | *Maschinenlesbarer Name*:MII_VS_Kardio_Extended_Condition_Severity_SNOMEDCT |

 
An extended ValueSet including standard condition severity and SNOMED CT code 42796001 (End-stage) 

 **References** 

* [MII PR Kardio Diagnose](StructureDefinition-mii-pr-kardio-diagnose.md)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-kardio-extended-condition-severity-snomedct",
  "language" : "de",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-kardio/ValueSet/mii-vs-kardio-extended-condition-severity-snomedct",
  "version" : "2027.0.0-ballot",
  "name" : "MII_VS_Kardio_Extended_Condition_Severity_SNOMEDCT",
  "title" : "MII VS Kardio Extended Condition Severity [SNOMED CT]",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-28T14:24:17+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "An extended ValueSet including standard condition severity and SNOMED CT code 42796001 (End-stage)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "24484000"
      },
      {
        "code" : "6736007"
      },
      {
        "code" : "255604002"
      },
      {
        "code" : "42796001"
      },
      {
        "code" : "261665006"
      }]
    }]
  }
}

```
